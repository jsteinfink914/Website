var searchData=
[
  ['best_5fsplit_0',['best_split',['../class_classifier_algorithm_class_1_1_decision_tree_classifier.html#ad51f42c17d3842b67df839b2bec1d66b',1,'ClassifierAlgorithmClass::DecisionTreeClassifier']]]
];
