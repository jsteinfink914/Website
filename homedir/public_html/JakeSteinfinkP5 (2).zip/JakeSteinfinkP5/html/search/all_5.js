var searchData=
[
  ['findmedian_0',['findMedian',['../class_data_set_class_1_1_data_set.html#ace77866fc06cb11987a0c2edf0a8e149',1,'DataSetClass::DataSet']]]
];
