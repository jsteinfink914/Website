var searchData=
[
  ['heterogeneousdata_0',['HeterogeneousData',['../class_data_set_class_1_1_heterogeneous_data.html',1,'DataSetClass']]]
];
