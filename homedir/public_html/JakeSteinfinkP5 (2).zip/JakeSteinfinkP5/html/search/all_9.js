var searchData=
[
  ['roc_0',['ROC',['../class_experiment_class_1_1_experiment.html#add6303cf359d585eba5af62c83a2c6cc',1,'ExperimentClass::Experiment']]],
  ['runcrossval_1',['runCrossVal',['../class_experiment_class_1_1_experiment.html#a17eaa47f2b05d95694c829ef51e8b652',1,'ExperimentClass::Experiment']]]
];
