var searchData=
[
  ['score_0',['score',['../class_experiment_class_1_1_experiment.html#a7cb9d5f8c3021dac256faa4983425367',1,'ExperimentClass::Experiment']]],
  ['select_1',['select',['../class_data_set_class_1_1_heterogeneous_data.html#a716b77c913dd511b766ab6784fc1a9c9',1,'DataSetClass::HeterogeneousData']]],
  ['simpleknnclassifier_2',['simpleKNNClassifier',['../class_classifier_algorithm_class_1_1simple_k_n_n_classifier.html',1,'ClassifierAlgorithmClass']]]
];
