var searchData=
[
  ['words_0',['words',['../class_data_set_class_1_1_text_data_set.html#a109d7043d773211fc07d36b7a0135638',1,'DataSetClass::TextDataSet']]]
];
