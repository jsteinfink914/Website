var searchData=
[
  ['dataset_0',['DataSet',['../class_data_set_class_1_1_data_set.html',1,'DataSetClass']]],
  ['decisiontreeclassifier_1',['DecisionTreeClassifier',['../class_classifier_algorithm_class_1_1_decision_tree_classifier.html',1,'ClassifierAlgorithmClass']]]
];
