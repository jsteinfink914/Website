var searchData=
[
  ['data_0',['data',['../class_data_set_class_1_1_time_series_data_set.html#ac3c45c6751cdb7e23cf8dde8f6f919be',1,'DataSetClass::TimeSeriesDataSet']]]
];
